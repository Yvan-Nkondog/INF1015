#pragma once

enum Colors
{
	DEFAULT = 0,
	RED = 91,
	GREEN = 92,
	BLUE = 94
};
