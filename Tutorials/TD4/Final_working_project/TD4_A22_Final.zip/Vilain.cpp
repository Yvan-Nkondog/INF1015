#include <iostream>
#include <string>
#include <cstddef>
#include "Personnage.hpp"
#include "Vilain.hpp"
#include "Colors.hpp"


Vilain::Vilain(const std::string& nom, const std::string& parution,
	const std::string& objectif) :
	Personnage(nom, parution),
	objectif_(objectif)
{}

Vilain::Vilain(const Vilain& autre) :
	Vilain(autre.getNom(), autre.getParution(), autre.objectif_)
{}

std::ostream& Vilain::afficher(std::ostream& os) const
{
	changerCouleur(os, Colors::RED);
	Personnage::afficher(os);
	return afficherObjectif(os);
}

const std::string& Vilain::getNomVilain() const
{
	return Personnage::getNom();
}

const std::string& Vilain::getParutionVilain() const
{
	return Personnage::getParution();
}

const std::string& Vilain::getObjectif() const
{
	return objectif_;
}

std::ostream& Vilain::afficherObjectif(std::ostream& os) const
{
	return os << "Objectif : " << objectif_ << std::endl;
}
