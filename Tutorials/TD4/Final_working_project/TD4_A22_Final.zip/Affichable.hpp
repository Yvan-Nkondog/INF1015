#pragma once
#include <iostream>
#include <string>
#include <cstddef>


class Affichable {
public:
	virtual std::ostream& afficher(std::ostream& os) const = 0;
	virtual std::ostream& changerCouleur(std::ostream& os, int couleur) const = 0;
	virtual ~Affichable() = default;
};
