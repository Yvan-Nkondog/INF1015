#pragma once
#include <iostream>
#include <string>
#include <cstddef>
#include "Personnage.hpp"


class Vilain : virtual public Personnage {
public:
	Vilain(const std::string& nom, const std::string& parution,
		const std::string& objectif);

	Vilain(const Vilain& autre);

	std::ostream& afficher(std::ostream& os) const override;

	const std::string& getNomVilain() const;

	const std::string& getParutionVilain() const;

protected:
	const std::string& getObjectif() const;

	std::ostream& afficherObjectif(std::ostream& os) const;

private:
	std::string objectif_;
};
