#pragma once
#include <iostream>
#include <string>
#include <cstddef>
#include "Affichable.hpp"


class Personnage : public Affichable {
public:
	Personnage(const std::string& nom, const std::string& parution); 
	
	~Personnage() = default;

	std::ostream& changerCouleur(std::ostream& os, int couleur) const;

protected:
	std::ostream& afficher(std::ostream& os) const override;

	const std::string& getNom() const;

	const std::string& getParution() const;

private:
	std::string nom_;
	std::string parution_;
};
