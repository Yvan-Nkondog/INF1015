#include <iostream>
#include <string>
#include <cstddef>
#include "Affichable.hpp"
#include "Personnage.hpp"


Personnage::Personnage(const std::string& nom, const std::string& parution) :
	nom_(nom),
	parution_(parution)
{}

std::ostream& Personnage::changerCouleur(std::ostream& os, int couleur) const
{
	return os << "\033[" << couleur << "m";
}

std::ostream& Personnage::afficher(std::ostream& os) const
{
	os << "Nom : " << nom_ << std::endl;
	os << "Parution : " << parution_ << std::endl;
	return os;
}

const std::string& Personnage::getNom() const
{
	return nom_;
}

const std::string& Personnage::getParution() const
{
	return parution_;
}
