﻿#include "lectureBinaire.hpp"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <cstddef>
#include <cassert>
#include <vector>
#include <memory>
#include "bibliotheque_cours.hpp"
#include "cppitertools/range.hpp"
#include "Affichable.hpp"
#include "Personnage.hpp"
#include "Vilain.hpp"
#include "Heros.hpp"
#include "VilainHeros.hpp"
#include "Colors.hpp"
using namespace std;

// Ligne de separation
static const string LIGNE_SEPARATION = 
	"═════════════════════════════════════════════════════════════════════════";

ifstream ouvrirFichierBinaire(const string& nomFichier)
{
	ifstream fichier(nomFichier, ios::binary);
	fichier.exceptions(ios::failbit);
	return fichier;
}

void testsPourCouvertureLectureBinaire()
{
	istringstream iss("\xA0\x12\xA1\x21\x43\xA2\x98\xBA\xDC\xFE");
	assert(lireUintTailleVariable(iss) == 0x12);
	assert(lireUintTailleVariable(iss) == 0x4321);
	assert(lireUintTailleVariable(iss) == 0xFEDCBA98);
}

void lireHeros(std::ifstream& fichier, vector<std::unique_ptr<Heros>>& herosVector)
{
	std::size_t nHeros = lireUintTailleVariable(fichier);
	for (std::size_t i = 0; i < nHeros; i++) {
		std::string nom = lireString(fichier);
		std::string parution = lireString(fichier);
		std::string ennemi = lireString(fichier);
		Heros heros = Heros(nom, parution, ennemi);
		std::size_t nAllies = lireUintTailleVariable(fichier);
		for (std::size_t j = 0; j < nAllies; j++) {
			std::string allie = lireString(fichier);
			(heros.getAllies()).push_back(allie);
		}
		herosVector.push_back(std::make_unique<Heros>(heros));
	}
}

void lireVilain(std::ifstream& fichier, vector<std::unique_ptr<Vilain>>& vilainVector)
{
	std::size_t nVilains = lireUintTailleVariable(fichier);
	for (std::size_t i = 0; i < nVilains; i++) {
		std::string nom = lireString(fichier);
		std::string parution = lireString(fichier);
		std::string objectif = lireString(fichier);
		vilainVector.push_back(std::make_unique<Vilain>(nom, parution, objectif));
	}
}

void afficherDerivesPersonnages(const vector<std::unique_ptr<Personnage>>& personnages)
{
	for (std::size_t i : iter::range(personnages.size())) {
		if (auto heros = dynamic_cast<Heros*>(personnages[i].get())) {
			heros->afficher(std::cout);
			std::cout << LIGNE_SEPARATION << std::endl;
		}
		else if (auto vilain = dynamic_cast<Vilain*>(personnages[i].get())) {
			vilain->afficher(std::cout);
			std::cout << LIGNE_SEPARATION << std::endl;
		}
		else {
			auto vilainHeros = dynamic_cast<VilainHeros*>(personnages[i].get());
			vilainHeros->afficher(std::cout);
			std::cout << LIGNE_SEPARATION << std::endl;
		}
	}
}

void separerSection(const std::string& titre)
{
	std::cout << LIGNE_SEPARATION << "\n\n" << std::endl;
	std::cout << titre << std::endl;
	std::cout << LIGNE_SEPARATION << std::endl;
}


int main()
{
	#pragma region "Bibliothèque du cours"
	// Permet sous Windows les "ANSI escape code" pour changer de couleur
	// https://en.wikipedia.org/wiki/ANSI_escape_code ; les consoles Linux/Mac
	// les supportent normalement par défaut.
	bibliotheque_cours::activerCouleursAnsi();
	#pragma endregion
	
	testsPourCouvertureLectureBinaire();

	// Ouverture des fichiers binaires
	ifstream fichierHeros = ouvrirFichierBinaire("heros.bin");
	ifstream fichierVilains = ouvrirFichierBinaire("vilains.bin");

	//TODO: Votre code pour le main commence ici (mais vous pouvez aussi ajouter/modifier du code avant si nécessaire)
	
	// TODO: Créer d’abord trois vecteurs : un de type Heros, un autre de type 
	// Vilain et le dernier pour y mettre des Personnages.
	vector<std::unique_ptr<Personnage>> personnages;
	vector<std::unique_ptr<Vilain>> vilains;
	vector<std::unique_ptr<Heros>> heros;

	// TODO: Faire la lecture des deux fichiers binaires afin de placer les 
	// héros et les vilains dans les bons vecteurs. Voir l’annexe 1 pour 
	// la structure des fichiers binaires.
	lireHeros(fichierHeros, heros);
	lireVilain(fichierVilains, vilains);

	// TODO: Afficher tous vos héros séparés par une ligne et tous vos vilains 
	// séparés par une ligne avec des boucles for en faisant appel à la méthode 
	// afficher, de manière à ce que l’information s’affiche à la console.
	// Afficher les informations des héros d’une couleur différente de celles 
	// des vilains. Par exemple en bleu pour les héros, en rouge pour les vilains.
	separerSection("Heros");
	for (std::size_t i : iter::range(heros.size())) {
		heros[i]->afficher(std::cout);
		std::cout << LIGNE_SEPARATION << std::endl;
	}

	separerSection("Vilains");
	for (std::size_t i : iter::range(vilains.size())) {
		vilains[i]->afficher(std::cout);
		std::cout << LIGNE_SEPARATION << std::endl;
	}

	// TODO: Placer tous les héros et vilains dans le vecteur de personnages. 
	// Le polymorphisme nous permet une telle opération car les héros et 
	// les vilains sont des personnages.
	for (std::size_t i : iter::range(heros.size())) {
		personnages.push_back(std::make_unique<Heros>(*(heros[i])));
	}

	for (std::size_t i : iter::range(vilains.size())) {
		personnages.push_back(std::make_unique<Vilain>(*(vilains[i])));
	}

	// TODO: Afficher ensuite chaque personnage du vecteur de personnages 
	// toujours en faisant appel à la méthode afficher, encore avec les 
	// héros et vilains de couleurs différentes.
	separerSection("Personnages");
	afficherDerivesPersonnages(personnages);

	// TODO: Finalement, créer un VilainHero en passant à son constructeur 
	// un vilain et héros de votre choix, venant des vecteurs de vilains et 
	// héros, en autant que le vilain n’est pas l’ennemi du héro !
	// Afficher - le à l’écran avec une troisième couleur, par exemple en
	// mauve.L’ajouter aussi au vecteur de personnages pour voir si l’affichage
	// du vecteur fonctionne correctement pour tous nos types de personnages
	// (les héros, vilains et vilains héros sont affichés correctement avec 
	// toutes leurs informations, et des couleurs différentes).
	separerSection("VilainHeros");
	std::unique_ptr<VilainHeros> vilainHeros = 
		std::make_unique<VilainHeros>((*(vilains[0])), (*(heros[2])));
	vilainHeros->afficher(std::cout);
	std::cout << LIGNE_SEPARATION << std::endl;

	separerSection("Personnages");
	personnages.push_back(std::move(vilainHeros));
	afficherDerivesPersonnages(personnages);

	// Rétablir la couleur de base / par défaut de std::cout
	personnages[0]->changerCouleur(std::cout, Colors::DEFAULT);
}
