#pragma once
#include <iostream>
#include <string>
#include <cstddef>
#include <vector>
#include "Personnage.hpp"


class Heros : virtual public Personnage {
public:
	Heros(const std::string& nom, const std::string& parution,
		const std::string& ennemi); 

	Heros(const Heros& autre);

	std::ostream& afficher(std::ostream& os) const override;
	
	const std::string& getNomHeros() const;

	const std::string& getParutionHeros() const;

	std::vector<std::string>& getAllies();

protected:
	std::ostream& afficherEnnemisEtAllies(std::ostream& os) const;

private:
	std::string ennemi_;
	std::vector<std::string> allies_;
};
