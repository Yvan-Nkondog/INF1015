#include <iostream>
#include <string>
#include <cstddef>
#include <vector>
#include "Personnage.hpp"
#include "Heros.hpp"
#include "cppitertools/range.hpp"
#include "Colors.hpp"


Heros::Heros(const std::string& nom, const std::string& parution,
	const std::string& ennemi) :
	Personnage(nom, parution),
	ennemi_(ennemi)
{
}

Heros::Heros(const Heros& autre) :
	Heros(autre.getNom(), autre.getParution(), autre.ennemi_)
{
	for (std::size_t i : iter::range(autre.allies_.size())) {
		allies_.push_back(autre.allies_[i]);
	}
}

std::ostream& Heros::afficher(std::ostream& os) const
{
	changerCouleur(os, Colors::BLUE);
	Personnage::afficher(os);
	return afficherEnnemisEtAllies(os);
}

const std::string& Heros::getNomHeros() const
{
	return Personnage::getNom();
}

const std::string& Heros::getParutionHeros() const
{
	return Personnage::getParution();
}

std::vector<std::string>& Heros::getAllies()
{
	return allies_;
}

std::ostream& Heros::afficherEnnemisEtAllies(std::ostream& os) const
{
	os << "Ennemi : " << ennemi_ << std::endl;
	os << "Allies : " << std::endl;
	for (std::size_t i = 0; i < allies_.size(); i++) {
		os << "\t" << allies_[i] << std::endl;
	}
	return os;
}
