#pragma once
#include <iostream>
#include <string>
#include <cstddef>
#include "Personnage.hpp"
#include "Vilain.hpp"
#include "Heros.hpp"


class VilainHeros : public Vilain, public Heros {
public:
	VilainHeros(const Vilain& vilain, const Heros& heros);

	std::ostream& afficher(std::ostream& os) const override;

private:
	std::string missionSpeciale_;
};
