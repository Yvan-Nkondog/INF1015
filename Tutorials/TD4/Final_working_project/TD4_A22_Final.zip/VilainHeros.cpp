#include <iostream>
#include <string>
#include <cstddef>
#include "Personnage.hpp"
#include "Vilain.hpp"
#include "Heros.hpp"
#include "Vilainheros.hpp"
#include "Colors.hpp"


VilainHeros::VilainHeros(const Vilain& vilain, const Heros& heros) :
	Personnage(vilain.getNomVilain() + "-" + heros.getNomHeros(),
		vilain.getParutionVilain() + "-" + heros.getParutionHeros()),
	Vilain(vilain),
	Heros(heros),
	missionSpeciale_(Vilain::getObjectif() + " dans le monde de " + heros.getNomHeros())
{}

std::ostream& VilainHeros::afficher(std::ostream& os) const
{
	// std::u8string missionSpeciale = u8"Mission spéciale : ";
	changerCouleur(os, Colors::GREEN);
	Personnage::afficher(os);
	Vilain::afficherObjectif(os);
	Heros::afficherEnnemisEtAllies(os);
	os << "Mission speciale : " << missionSpeciale_ << std::endl;
	return os;
}
