#include "Developpeur.hpp"
#include "Liste.hpp"
#include "Jeu.hpp"
#include "cppitertools/range.hpp"
#include <iostream>
#include "debogage_memoire.hpp"  //NOTE: Incompatible avec le "placement new", ne pas utiliser cette ent�te si vous utilisez ce type de "new" dans les lignes qui suivent cette inclusion.
using namespace std;

Developpeur::Developpeur(const string& nom)
{
	paireNomJeux_ = { nom, Liste<Jeu>{} };
}

Developpeur::~Developpeur()
{
	delete[] paireNomJeux_.second.elements_; // Les objets jeux n'appartiennent pas � la liste, donc on ne fait pas de detruireListeJeux (ou on pourrait avoir une version de detruireListeJeux qui ne d�truit pas les jeux).
}

void Developpeur::ajouterJeux(Liste<Jeu>& listeJeux)
{
	paireNomJeux_.second.changerTaille(compterJeuxDeveloppes(listeJeux));
	for (Jeu*& j : listeJeux.spanListe()) // Ici, ListeJeux est externe � la classe
	{
		if (j->developpeur == getNom())
			paireNomJeux_.second.ajouter(j);
	}
}

void Developpeur::afficher() const
{
	cout << "\n" << getNom() << " a d�velopp� les jeux suivants :" << endl;
	if (paireNomJeux_.second.nElements_ > 0) {
		for (Jeu*& j : paireNomJeux_.second.spanListe())
			cout << "\t\033[33m" << j->titre << "\033[0m" << endl;
	}
	else
		cout << "\t\033[31m" << "Aucun jeu trouv�, r�essayez" << "\033[0m" << endl;
}

unsigned int Developpeur::compterJeuxDeveloppes(Liste<Jeu>& listeJeux)
{
	unsigned int n = 0;
	for (Jeu*& j : listeJeux.spanListe()) {
		if (j->developpeur == getNom())
			n++;
	}
	return n;
}
