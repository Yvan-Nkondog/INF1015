﻿#pragma once
#include <iostream>
#include <string>
#include "Liste.hpp"

struct Jeu;  // Déclaration avancée pour permettre au compilateur de savoir que 
			// la struct jeu existe. La déclaration avancée remplace le 
			// " #include Jeu.hpp " afin d'éviter les dépendances circulaires.

struct Concepteur
{
	friend std::ostream& operator<<(std::ostream& os, const Concepteur& concepteur);

	std::string nom;
	int anneeNaissance;
	std::string pays;
	Liste<Jeu> jeuxConcus;
};
