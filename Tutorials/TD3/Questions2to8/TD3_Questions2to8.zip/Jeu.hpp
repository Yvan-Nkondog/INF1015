﻿#pragma once
#include <string>
#include <iostream>
#include "Liste.hpp"
#include "Concepteur.hpp"

struct Jeu
{
	template<typename PredicatUnaire>
	Concepteur* chercherConcepteur(const PredicatUnaire& critere) const
	{
		return concepteurs.chercherElement(critere);
	}

	friend std::ostream& operator<<(std::ostream& os, const Jeu& jeu);

	std::string titre;
	int anneeSortie;
	std::string developpeur;
	Liste<Concepteur> concepteurs;
};
