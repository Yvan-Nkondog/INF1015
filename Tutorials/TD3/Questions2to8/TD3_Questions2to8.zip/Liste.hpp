#pragma once
#include <iostream>
#include "gsl/span" 
#include "cppitertools/range.hpp"


template<typename T>
class Liste {
public:
	Liste() = default;

	// Note : Le constructeur de copie Liste(const Liste& autre) { ... }
	// n'a pas été implémentée parce que la fonction lireJeu dans le "main"
	// crée un jeu d'une manière totalement distincte que la présente 
	// classe. Ainsi, l'assignation a été utilisé pour réaliser la copie
	// requise pour la question 7.

	~Liste() {}

	Liste& operator=(const Liste& autre) {
		if (this != &autre) {
			delete[] elements_;
			elements_ = new T*[capacite_];
			for (std::size_t i = 0; i < autre.nElements_; i++) {
				ajouter(autre.elements_[i]);
			}
		}
		return *this;
	}

	void changerTaille(std::size_t nouvelleCapacite)
	{
		T** nouvelleListe = new T * [nouvelleCapacite];
		for (size_t i : iter::range(nElements_)) {
			nouvelleListe[i] = elements_[i];
		}
		delete[] elements_;
		elements_ = nouvelleListe;
		capacite_ = nouvelleCapacite;
	}

	void ajouter(T* t)
	{
		if (nElements_ == capacite_) {
			changerTaille(std::max(size_t(1), capacite_ * 2));
		}
		elements_[nElements_] = t;
		nElements_++;
	}

	void afficher() const
	{
		for (const T* t : spanListe())
			t->afficher();
	}

	void retirer(T* t)
	{
		for (T*& ptrT : spanListe()) {
			if (ptrT == t) {
				if (nElements_ > 1)
					ptrT = elements_[nElements_ - 1];
				nElements_--;
			}
		}
	}

	gsl::span<T*> spanListe() const
	{
		return gsl::span(elements_, nElements_);
	}

	gsl::span<T*> spanListe()
	{
		return gsl::span(elements_, nElements_);
	}


	T& operator[](int index) 
	{
		return *(elements_[index]);
	}

	const T& operator[](int index) const
	{
		return *(elements_[index]);
	}

	template<typename PredicatUnaire>
	T* chercherElement(const PredicatUnaire& critere) const {
		for (T*& ptrT : spanListe()) {
			if (critere(ptrT)) {
				return ptrT;
			}
		}
		return nullptr;
	}

	std::size_t nElements_ = 0, capacite_ = 0;  
	T** elements_ = nullptr;
};
