﻿#include "Jeu.hpp"
#include <iostream>
#include <fstream>
#include <cstdint>
#include <cassert>
#include "Concepteur.hpp"
#include "Liste.hpp"
#include "Developpeur.hpp"
#include "cppitertools/range.hpp"
#include "gsl/span"
#include "bibliotheque_cours.hpp"
#include "verification_allocation.hpp"
#include "debogage_memoire.hpp"  //NOTE: Incompatible avec le "placement new", ne pas utiliser cette entête si vous utilisez ce type de "new" dans les lignes qui suivent cette inclusion.

using namespace std;
using namespace iter;
using namespace gsl;

#pragma region "Fonctions de base pour vous aider"
template <typename T>
T lireType(istream& fichier)
{
	T valeur{};
	fichier.read(reinterpret_cast<char*>(&valeur), sizeof(valeur));
	return valeur;
}
#define erreurFataleAssert(message) assert(false&&(message)),terminate()
static const uint8_t enteteTailleVariableDeBase = 0xA0;
size_t lireUintTailleVariable(istream& fichier)
{
	uint8_t entete = lireType<uint8_t>(fichier);
	switch (entete) {
	case enteteTailleVariableDeBase+0: return lireType<uint8_t>(fichier);
	case enteteTailleVariableDeBase+1: return lireType<uint16_t>(fichier);
	case enteteTailleVariableDeBase+2: return lireType<uint32_t>(fichier);
	default:
		erreurFataleAssert("Tentative de lire un entier de taille variable alors que le fichier contient autre chose à cet emplacement.");
	}
}

string lireString(istream& fichier)
{
	string texte;
	texte.resize(lireUintTailleVariable(fichier));
	fichier.read((char*)&texte[0], streamsize(sizeof(texte[0])) * texte.length());
	return texte;
}
#pragma endregion

//TODO: Fonction qui cherche un concepteur par son nom dans une ListeJeux.
// Cette fonction renvoie le pointeur vers le concepteur si elle le trouve dans
// un des jeux de la ListeJeux. En cas contraire, elle renvoie un pointeur nul.
Concepteur* trouverConcepteur(const Liste<Jeu>& listeJeux, string nom)
{
	Concepteur* concepteur = nullptr;
	for (const Jeu* j : listeJeux.spanListe()) {
		//TODO: Modifier la fonction trouverConcepteur (appliquée sur
		// la liste de jeux lors de la lecture du fichier) pour utiliser
		// la méthode de la class template (Liste).
		concepteur = j->chercherConcepteur([&nom](Concepteur* ptrConcepteur)
			{
				return ptrConcepteur->nom == nom;
			});
	}
	return concepteur;
}

// TODO : Mettre à jour la fonction avec la nouvelle classe template Liste<T>.
Concepteur* lireConcepteur(istream& fichier, Liste<Jeu>& listeJeux)
{
	Concepteur concepteur = {}; // On initialise une structure vide de type Concepteur.
	concepteur.nom = lireString(fichier);
	concepteur.anneeNaissance = int(lireUintTailleVariable(fichier));
	concepteur.pays = lireString(fichier);
	// Rendu ici, les champs précédents de la structure concepteur sont remplis
	// avec la bonne information.

	//TODO: Ajouter en mémoire le concepteur lu. Il faut revoyer le pointeur créé.
	// Attention, valider si le concepteur existe déjà avant de le créer, sinon
	// on va avoir des doublons car plusieurs jeux ont des concepteurs en commun
	// dans le fichier binaire. Pour ce faire, cette fonction aura besoin de
	// la liste de jeux principale en paramètre.
	// Afficher un message lorsque l'allocation du concepteur est réussie.
	Concepteur* concepteurExistant = trouverConcepteur(listeJeux, concepteur.nom);
	if (concepteurExistant != nullptr)
		return concepteurExistant;

	//cout << concepteur.nom << endl;  //TODO: Enlever cet affichage temporaire servant à voir que le code fourni lit bien les jeux.
	cout << "\033[92m" << "Allocation en mémoire du concepteur " << concepteur.nom
				<< "\033[0m" << endl;
	return new Concepteur(concepteur); //TODO: Retourner le pointeur vers le concepteur crée.
}

//TODO: Fonction qui change la taille du tableau de jeux de ListeJeux.
// Cette fonction doit recevoir en paramètre la nouvelle capacité du nouveau
// tableau. Il faut allouer un nouveau tableau assez grand, copier ce qu'il y
// avait dans l'ancien, et éliminer l'ancien trop petit. N'oubliez pas, on copie
// des pointeurs de jeux. Il n'y a donc aucune nouvelle allocation de jeu ici !
void changerTailleListeJeux(Liste<Jeu>& liste, size_t nouvelleCapacite)
{
	assert(nouvelleCapacite >= liste.nElements_); // On ne demande pas de supporter les réductions de nombre d'éléments.
	Jeu** nouvelleListeJeux = new Jeu* [nouvelleCapacite];
	// Pas nécessaire de tester si liste.elements est nullptr puisque si c'est le cas, nElements est nécessairement 0.
	for (size_t i : iter::range(liste.nElements_))
		nouvelleListeJeux[i] = liste.elements_[i];
	delete[] liste.elements_;

	liste.elements_ = nouvelleListeJeux;
	liste.capacite_ = nouvelleCapacite;
}

// TODO : Mettre à jour la fonction avec la nouvelle classe template Liste<T>.
Jeu* lireJeu(istream& fichier, Liste<Jeu>& listeJeux)
{
	Jeu jeu = {}; // On initialise une structure vide de type Jeu
	jeu.titre = lireString(fichier);
	jeu.anneeSortie = int(lireUintTailleVariable(fichier));
	jeu.developpeur = lireString(fichier);
	jeu.concepteurs.nElements_ = lireUintTailleVariable(fichier);
	// Rendu ici, les champs précédents de la structure jeu sont remplis avec la
	// bonne information.

	//TODO: Ajouter en mémoire le jeu lu. Il faut revoyer le pointeur créé.
	// Attention, il faut aussi créer un tableau dynamique pour les concepteurs
	// que contient un jeu. Servez-vous de votre fonction d'ajout de jeu car la
	// liste de jeux participé est une ListeJeu. Afficher un message lorsque
	// l'allocation du jeu est réussie.
	Jeu* ptrJeu = new Jeu(jeu);  // Ou allouer directement au début plutôt qu'en faire une copie ici.
	cout << "\033[96m" << "Allocation en mémoire du jeu " << jeu.titre
			  << "\033[0m" << endl;
	// On n'a pas demandé de faire une réallocation dynamique pour les designers.
	ptrJeu->concepteurs.elements_ = new Concepteur* [ptrJeu->concepteurs.nElements_];  
	for (Concepteur*& c : ptrJeu->concepteurs.spanListe()) {
		//TODO: Mettre le concepteur dans la liste des concepteur du jeu.
		c = lireConcepteur(fichier, listeJeux); 
		//TODO: Ajouter le jeu à la liste des jeux auquel a participé le concepteur.
		c->jeuxConcus.ajouter(ptrJeu);
	}
	return ptrJeu; //TODO: Retourner le pointeur vers le nouveau jeu.
}

// TODO : Mettre à jour la fonction avec la nouvelle classe template Liste<T>.
Liste<Jeu> creerListeJeux(const string& nomFichier)
{
	ifstream fichier(nomFichier, ios::binary);
	fichier.exceptions(ios::failbit);
	size_t nElements = lireUintTailleVariable(fichier);
	Liste<Jeu> listeJeux = {};
	for([[maybe_unused]] size_t n : iter::range(nElements))
	{
		//TODO: Ajouter le jeu à la ListeJeux.
		listeJeux.ajouter(lireJeu(fichier, listeJeux));
	}

	return listeJeux; //TODO: Renvoyer la ListeJeux.
}

//TODO: Fonction pour détruire un concepteur (libération de mémoire allouée).
// Lorsqu'on détruit un concepteur, on affiche son nom pour fins de débogage.
void detruireConcepteur(Concepteur* concepteur)
{
	cout << "\033[91m" << "Destruction du concepteur " << concepteur->nom << "\033[0m"
			  << endl;
	delete[] concepteur->jeuxConcus.elements_;
	delete concepteur;
}

//TODO: Fonction qui détermine si un concepteur participe encore à un jeu.
bool encorePresentDansUnJeu(const Concepteur* concepteur)
{
	return concepteur->jeuxConcus.nElements_ != 0;
}

//TODO: Fonction pour détruire un jeu (libération de mémoire allouée).
// Attention, ici il faut relâcher toute les cases mémoires occupées par un jeu.
// Par conséquent, il va falloir gérer le cas des concepteurs (un jeu contenant
// une ListeConcepteurs). On doit commencer par enlever le jeu à détruire des jeux
// qu'un concepteur a participé (jeuxConcus). Si le concepteur n'a plus de
// jeux présents dans sa liste de jeux participés, il faut le supprimer.  Pour
// fins de débogage, affichez le nom du jeu lors de sa destruction.
void detruireJeu(Jeu* jeu)
{
	// TODO : Mettre à jour la fonction avec la nouvelle classe template Liste<T>.
	for (Concepteur* c : jeu->concepteurs.spanListe()) {
		c->jeuxConcus.retirer(jeu);
		if (!encorePresentDansUnJeu(c))
			detruireConcepteur(c);
	}
	cout << "\033[31m" << "Destruction du jeu " << jeu->titre << "\033[0m"
			  << endl;
	delete[] jeu->concepteurs.elements_;
	delete jeu;
}

//TODO: Fonction pour détruire une ListeJeux et tous ses jeux.
void detruireListeJeux(Liste<Jeu>& liste)
{
	for(Jeu* j : liste.spanListe())
		detruireJeu(j);
	delete[] liste.elements_;
}

// Lignes de codes ajoutées pour la surcharge d'opérateur d'affichage.
std::ostream& operator<<(std::ostream& os, const Concepteur& concepteur)
{
	os << "\t" << concepteur.nom << ", " << concepteur.anneeNaissance << ", "
		<< concepteur.pays << std::endl;
	return os;
}

std::ostream& operator<<(std::ostream& os, const Jeu& jeu)
{
	os << "Titre : " << "\033[94m" << jeu.titre << "\033[0m" << endl;
	os << "Parution : " << "\033[94m" << jeu.anneeSortie << "\033[0m"
		<< endl;
	os << "Développeur :  " << "\033[94m" << jeu.developpeur << "\033[0m"
		<< endl;
	os << "Concepteurs du jeu :" << "\033[94m" << endl;
	for (const Concepteur* concepteur : jeu.concepteurs.spanListe())
		os << (*concepteur);
	os << "\033[0m";
	return os;
}

std::ostream& operator<<(std::ostream& os, const Liste<Jeu>& listeJeux)
{
	static const string ligneSeparation = "\n\033[95m"
		"══════════════════════════════════════════════════════════════════════════"
		"\033[0m\n";
	os << ligneSeparation << std::endl;
	for (const Jeu* jeu : listeJeux.spanListe())
	{
		os << (*jeu);;
		os << ligneSeparation << std::endl;
	}
	return os;
}


int main([[maybe_unused]] int argc, [[maybe_unused]] char** argv)
{
	#pragma region "Bibliothèque du cours"
	// Permet sous Windows les "ANSI escape code" pour changer de couleur
	// https://en.wikipedia.org/wiki/ANSI_escape_code ; les consoles Linux/Mac
	// les supportent normalement par défaut.
	bibliotheque_cours::activerCouleursAnsi(); 
	#pragma endregion

	// Pour vérifier que la détection de fuites fonctionne; un message 
	// devrait dire qu'il y a une fuite à cette ligne.
	//int* fuite = new int; 

	//TODO: Appeler correctement votre fonction de création de la liste de jeux.
	Liste<Jeu> lj = creerListeJeux("jeux.bin"); 

	static const string ligneSeparation = "\n\033[35m════════════════════════════════════════\033[0m\n";
	cout << ligneSeparation << endl;
	cout << "Premier jeu de la liste :" << endl;
	// TODO : Implémentation : Question 6
	//TODO: Afficher le premier jeu de la liste (en utilisant la fonction).  
	// Devrait être Chrono Trigger.
	std::cout << "Question6 : " << std::endl;
	std::cout << (*lj.elements_[0]) << std::endl;
	cout << ligneSeparation << endl;

	//TODO: Appel à votre fonction d'affichage de votre liste de jeux.
	std::cout << lj << std::endl;

	// Ajouter la liste à un fichier.
	ofstream("sortie.txt") << lj;

	// TODO : Implémentation : Question 3
	// Vérifier que le nombre nElements_ de la Liste lj est 18 et que
	// la capacité du tableau est égale à 32.
	std::cout << ligneSeparation << std::endl;
	std::cout << "Question3 : " << std::endl;
	std::cout << "lj.nElements : " << lj.nElements_ << std::endl;
	std::cout << "lj.capacite : " << lj.capacite_ << std::endl;

	// TODO : Implémentation : Question 4
	// Pour tester l’opérateur[], et que la liste est bien créée,
	// vérifiez dans le main que le titre du jeu à l’indice 2 
	// est « Secret of Mana » et le nom de son concepteur à
	// l’indice 1 est « Hiromichi Tanaka »
	std::cout << ligneSeparation << std::endl;
	std::cout << "Question4 : " << std::endl;
	std::cout << "Jeu à l'indice 2 : " << lj[2].titre << std::endl;
	std::cout << "Deuxième concepteur du jeu à l'indice 2 : " << 
		lj[2].concepteurs.elements_[1]->nom << std::endl;

	// TODO : Implémentation : Question 7
	// Tester la copie (section 7, tp3)
	// Prendre le jeu à l’indice 2 et en faire une copie dans un nouveau 
	// Jeu copieJeu = *lj[2].
	// auto copieJeu = *(lj.elements_[2]);
	std::cout << ligneSeparation << std::endl;
	std::cout << "Question7 : " << std::endl;
	Jeu copieJeu; 
	copieJeu = *(lj.elements_[2]);

	// Remplacer le deuxième concepteur dans copieJeu par un autre 
	// venant du jeu à l’indice 0.
	copieJeu.concepteurs.elements_[1] = (*(lj.elements_[0])).concepteurs.elements_[2];

	// Affichez le jeu à l’indice 2 et sa copie modifiée, pour voir que les 
	// liste de concepteurs sont différentes.
	std::cout << "Comparaison de la liste des concepteurs du "
		<< "jeu à l'indice 2 et de sa copie modifiée : " << std::endl;
	std::cout << (*(lj.elements_[2])) << std::endl;
	std::cout << copieJeu << std::endl;
	std::cout << "Observation : Lorsqu'on modifie un concepteur dans " <<
		"la copie modifiée du jeu, le jeu d'origine (ou plutôt le concepteur " <<
		"dans le jeu d'origine n'est pas modifié.\n" << std::endl;
	// Vérifiez que l’adresse du premier Concepteur dans les deux listes 
	// est la même (donc que ce n’est pas une copie du concepteur).
	std::cout << "Verification des adresses du premier concepteur, " <<
		"non modifié, dans les deux listes : " << std::endl;
	std::cout << "Adresse dans le jeu original : " <<
		(*(lj.elements_[2])).concepteurs.elements_[0] << std::endl;

	std::cout << "Adresse dans la copie du jeu : " <<
		copieJeu.concepteurs.elements_[0] << std::endl;

	std::cout << "\nObservation : l'adresse du premier concepteur dans la copie " <<
		"du jeu et l'adresse du premier concepteur dans le jeu original sont " <<
		"pareilles. C'est le comportement attendu, puisque la copie d'une Liste<T> " <<
		"copie tous les pointeurs de deuxième niveau. " << std::endl;

	// Remettre le concepteur d'origine dans la copie après avoir testé l'affichage.
	copieJeu.concepteurs.elements_[1] = (*(lj.elements_[2])).concepteurs.elements_[1];

	// TODO : Implémentation : Question 5
	std::cout << ligneSeparation << std::endl;
	std::cout << "Question 5 : " << std::endl;

	std::cout << "Recherche du concepteur Yoshinori Kitase dans les " <<
		"jeux aux indices zéro et un : " << std::endl;
	Concepteur* yoshinoriKitase0 = lj[0].chercherConcepteur([](Concepteur* ptrConcepteur)
		{
			return ptrConcepteur->nom == "Yoshinori Kitase";
		});
	Concepteur* yoshinoriKitase1 = lj[1].chercherConcepteur([](Concepteur* ptrConcepteur)
		{
			return ptrConcepteur->nom == "Yoshinori Kitase";
		});

	std::cout << "Affichage des addresses des deux pointeurs obtenus : " << std::endl;
	std::cout << yoshinoriKitase0 << std::endl;
	std::cout << yoshinoriKitase1 << std::endl;

	std::cout << "Affichage de l'année de naissance pour le concepteur pointé par " <<
		"chaque pointeur : " << std::endl;
	std::cout << yoshinoriKitase0->anneeNaissance << std::endl;
	std::cout << yoshinoriKitase1->anneeNaissance << std::endl;

	std::cout << ligneSeparation << std::endl;
	
	//TODO: Faire les appels à toutes vos fonctions/méthodes pour voir qu'elles 
	// fonctionnent et avoir 0% de lignes non exécutées dans le programme 
	// (aucune ligne rouge dans la couverture de code; c'est normal que les 
	// lignes de "new" et "delete" soient jaunes).  Vous avez aussi le droit 
	// d'effacer les lignes du programmes qui ne sont pas exécutée, 
	// si finalement vous pensez qu'elle ne sont pas utiles.

	Liste<Developpeur> ld;
	// Création des développeurs externes à la liste des développeur
	Developpeur* nintendo = new Developpeur("Nintendo");
	Developpeur* square = new Developpeur("Square");
	Developpeur* konami = new Developpeur("Konami");
	Developpeur* bidon = new Developpeur("Bidon");
	// On ajoute les jeux respectifs de ListeJeux développé par le développeur
	nintendo->ajouterJeux(lj);
	square->ajouterJeux(lj);
	konami->ajouterJeux(lj);
	// On ajoute les développeurs à la ListeDeveloppeur car ils sont externes
	ld.ajouter(nintendo);
	ld.ajouter(square);
	ld.ajouter(konami);
	ld.ajouter(bidon);
	// On affiche la liste des développeurs, 
	// leurs jeux sont aussi affichés; Bidon ne devrait avoir aucun jeu.
	ld.afficher();

	cout << endl << "On retire " << bidon->getNom() << endl;
	ld.retirer(bidon); // Retire sans détruire.
	ld.afficher();
	cout << "Il existe encore: " << bidon->getNom() << endl;

	delete bidon;
	delete konami;
	delete square;
	delete nintendo;

	//TODO: Détruire tout avant de terminer le programme.  
	// Devrait afficher "Aucune fuite detectee." a la sortie du programme; 
	// il affichera "Fuite detectee:" avec la liste des blocs, 
	// s'il manque des delete.
	detruireListeJeux(lj);
}
