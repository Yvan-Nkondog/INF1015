﻿#pragma once
#include "gsl/gsl_assert"
#include "gsl/pointers"

template<typename T> class ListeLiee;
template<typename T> class Iterateur;

template<typename T>
struct Noeud
{
	friend class ListeLiee<T>;
	friend class Iterateur<T>;
public:
	//TODO: Constructeur(s).
	Noeud() = default;

	Noeud(const T& donnee) :
		donnee_(donnee)
	{}

private:
	//TODO: Attributs d'un noeud.
	Noeud* suivant_ = past_end;
	Noeud* precedent_ = past_end;
	T donnee_;
	inline static constexpr Noeud* past_end = nullptr;
};

template<typename T>
class Iterateur
{
	friend class ListeLiee<T>;
public:
	//TODO: Constructeur(s).
	Iterateur() = default;

	Iterateur(const Iterateur& autre) = default;

	Iterateur(Noeud<T>* position) :
		position_(position)
	{}

	void avancer()
	{
		Expects(position_ != nullptr);
		//TODO: Changez la position de l'itérateur pour le noeud suivant
		position_ = position_->suivant_;
	}

	void reculer()
	{
		//NOTE: On ne demande pas de supporter de reculer à partir de l'itérateur end().
		Expects(position_ != nullptr);
		//TODO: Changez la position de l'itérateur pour le noeud précédent
		position_ = position_->precedent_;
	}

	T& operator*()
	{
		return position_->donnee_;
	}

	//TODO: Ajouter ce qu'il manque pour que les boucles sur intervalles fonctionnent sur une ListeLiee.
	// bool operator==(const Iterateur<T>& it) const = default;
	bool operator==(const Iterateur<T>& it) const 
	{ 
		return it.position_ == position_;
	}

	Iterateur<T>& operator++ ()
	{
		avancer();
		return *this;
	}

	Iterateur<T>& operator--()
	{
		reculer();
		return *this;
	}

private:
	Noeud<T>* position_;
};

template<typename T>
class ListeLiee
{
	friend class Iterateur<T>;
public:
	using iterator = Iterateur<T>;  // Définit un alias au type, pour que ListeLiee<T>::iterator corresponde au type de son itérateur.

	//TODO: La construction par défaut doit créer une liste vide valide.
	ListeLiee() : 
		taille_(0), tete_(nullptr), queue_(nullptr)
	{}

	~ListeLiee()
	{
		//TODO: Enlever la tête à répétition jusqu'à ce qu'il ne reste aucun élément.
		// Pour enlever la tête, 
		// 1. La tête doit devenir le suivant de la tête actuelle.
		// 2. Ne pas oublier de désallouer le noeud de l'ancienne tête (si pas fait automatiquement).
		while (tete_->suivant_ != nullptr) {
			tete_ = tete_->suivant_;
			delete tete_->precedent_;
		}
		delete tete_;
	}

	bool estVide() const  { return taille_ == 0; }
	unsigned size() const { return taille_; }
	//NOTE: to_address (C++20) permet que ce même code fonctionne que vous utilisiez des
	// pointeurs bruts ou intelligents (ça prend le pointeur brut associé au pointeur 
	// intelligent, s'il est intelligent).
	iterator begin()  { return {to_address(tete_)}; }
	iterator end()    { return {to_address(queue_->suivant_)}; }

	// Ajoute à la fin de la liste.
	void push_back(const T& item)
	{
		//TODO: Vous devez créer un nouveau noeud en mémoire.
		Noeud<T>* noeud = new Noeud<T>(item);
		//TODO: Si la liste était vide, ce nouveau noeud est la tête et la queue;
		// autrement, ajustez la queue et pointeur(s) adjacent(s) en conséquence.
		if (estVide()) {
			tete_ = noeud;
		}
		else {
			queue_->suivant_ = noeud;
			noeud->precedent_ = queue_;
		}
		queue_ = noeud;
		++taille_;
	}

	// Insère avant la position de l'itérateur.
	iterator insert(iterator it, const T& item)
	{
		//NOTE: Pour simplifier, vous n'avez pas à supporter l'insertion à la fin (avant "past the end"),
		// ni l'insertion au début (avant la tête), dans cette méthode.
		//TODO:
		// 1. Créez un nouveau noeud initialisé avec item.
		Noeud<T>* noeud = new Noeud<T>(item);
		// 2. Modifiez les attributs suivant_ et precedent_ du nouveau noeud
		//    afin que le nouveau noeud soit lié au noeud précédent et suivant
		//    à l'endroit où il est inséré selon notre itérateur.
		noeud->suivant_ = it.position_;
		noeud->precedent_ = it.position_->precedent_;
		// 3. Modifiez l'attribut precedent_ du noeud après la position d'insertion
		//    (l'itérateur) afin qu'il pointe vers le noeud créé.
		it.position_->precedent_ = noeud;
		// 4. Modifiez l'attribut suivant_ du noeud avant la position d'insertion
		//    (précédent de l'itérateur) afin qu'il point vers le noeud créé.
		noeud->precedent_->suivant_ = noeud;
		// 5. Incrémentez la taille de la liste.
		++taille_;
		// 6. Retournez un nouvel itérateur initialisé au nouveau noeud.
		return iterator(noeud);
	}

	// Enlève l'élément à la position it et retourne un itérateur vers le suivant.
	iterator erase(iterator it)
	{
		//TODO: Enlever l'élément à la position de l'itérateur.
		//  1. Le pointeur vers le Noeud à effacer est celui dans l'itérateur.
		Noeud<T>* aEnlever = it.position_;
		//  2. Modifiez l'attribut suivant_ du noeud précédent pour que celui-ci
		//     pointe vers le noeud suivant la position de l'itérateur (voir 1.).
		Noeud<T>* noeudPrecedent = aEnlever->precedent_;
		Noeud<T>* noeudSuivant = aEnlever->suivant_;
		if (noeudPrecedent == nullptr) {
			tete_ = noeudSuivant;
		}
		else {
			noeudPrecedent->suivant_ = noeudSuivant;
		}
		//  3. Modifiez l'attribut precedent_ du noeud suivant la position de
		//     l'itérateur pour que celui-ci pointe vers le noeud précédent
		//     de la position de l'itérateur (voir 1.).
		noeudSuivant->precedent_ = noeudPrecedent;
		//  4. Désallouez le Noeud à effacer (voir 1.).
		delete aEnlever;
		//  5. Décrémentez la taille de la liste
		--taille_;
		//  6. Retournez un itérateur vers le suivant du Noeud effacé.
		return iterator(noeudSuivant);
		//TODO: On veut supporter d'enlever le premier élément de la liste,
		//  donc en 2, il se peut qu'il n'y ait pas de précédent et alors c'est
		//  la tête de liste qu'il faut ajuster.
		//NOTE: On ne demande pas de supporter d'effacer le dernier 
		// élément (c'est similaire au cas pour enlever le premier).
	}

private:
	gsl::owner<Noeud<T>*> tete_;  //NOTE: Vous pouvez changer le type si vous voulez.

	Noeud<T>* queue_;
	unsigned taille_;
};
