﻿#include "Personnage.hpp"
#include "Heros.hpp"
#include "Vilain.hpp"
#include "VilainHeros.hpp"
#include "lireVectorDuFichier.hpp"
#include "lectureBinaire.hpp"
#include "ListeLiee.hpp"
#include <fstream>
#include <sstream>
#include <cassert>
#include <vector>
#include <functional>
#include <memory>
#include <map>
#include "cppitertools/range.hpp"
#include "bibliotheque_cours.hpp"
using namespace std;
using namespace iter;

// Ligne de separation
static const string LIGNE_SEPARATION =
"═════════════════════════════════════════════════════════════════════════";

ifstream ouvrirFichierBinaire(const string& nomFichier)
{
	ifstream fichier(nomFichier, ios::binary);
	fichier.exceptions(ios::failbit);
	return fichier;
}

void testsPourCouvertureLectureBinaire()
{
	istringstream iss("\xA0\x12\xA1\x21\x43\xA2\x98\xBA\xDC\xFE");
	assert(lireUintTailleVariable(iss) == 0x12);
	assert(lireUintTailleVariable(iss) == 0x4321);
	assert(lireUintTailleVariable(iss) == 0xFEDCBA98);
}


// versReferenceAffichable permet d'avoir une référence à l'affichable, que le paramètre soit un unique_ptr ou une référence.  On aurait pu faire un template plus générique pour const/non const, et même utiliser un concept, mais ce n'est pas nécessaire pour que ça fonctionne.
// lireFichier aurait aussi pu retourner un vector de unique_ptr pour ne pas avoir besoin de versReferenceAffichable pour supporter à la fois les références et les unique_ptr.
const Affichable& versReferenceAffichable(const Affichable& p) { return p; }
template <typename T>
const Affichable& versReferenceAffichable(const unique_ptr<T>& p) { return *p; }


// Trait de separation
static const string trait =
	"═════════════════════════════════════════════════════════════════════════";

// On ne demande pas particulièrement la surcharge de << dans ce TD.
template <typename T>
void afficherAffichables(const vector<T>& affichables)
{
	static const string separateurElements = "\033[33m" + trait + "\033[0m\n";
	for (auto&& a : affichables) {
		cout << separateurElements;
		auto& x = versReferenceAffichable(a);
		x.changerCouleur(cout, 0);
		x.afficher(cout);
	}
}

// Permet d'avoir une référence non-const à un objet temporaire.
template <typename T> T& temporaireModifiable(T&& objet) { return objet; }

template <typename T>
vector<T> lireVectorDuFichier(const string& nomFichier)
{
	return lireVectorDuFichier<T>(temporaireModifiable(ouvrirFichierBinaire(nomFichier)));
}

template <typename T>
ListeLiee<T>::iterator trouverParNom(ListeLiee<T>& liste, const string& nom)
{
	//? Quand on accède à un membre dans un type qui n'est pas encore connu (ici T n'est pas connu donc ListeLiee<T> n'est pas connu non plus) lors de l'analyse syntaxique du programme, dans le cas général il ne peut pas savoir si ce membre est un type.  Pour cette raison on doit ajouter le mot typename devant pour lui dire.
	typename ListeLiee<T>::iterator fin = liste.end();
	for (typename ListeLiee<T>::iterator pos = liste.begin(); pos != fin; pos.avancer()) {
		if ((*pos).getNom() == nom)
			return pos;
	}
	return fin;
}

void separerSection(const std::string& titre)
{
	std::cout << LIGNE_SEPARATION << "\n\n" << std::endl;
	std::cout << titre << std::endl;
	std::cout << LIGNE_SEPARATION << std::endl;
}

int main()
{
	#pragma region "Bibliothèque du cours"
	// Permet sous Windows les "ANSI escape code" pour changer de couleur
	// https://en.wikipedia.org/wiki/ANSI_escape_code ; les consoles Linux/Mac
	// les supportent normalement par défaut.
	bibliotheque_cours::activerCouleursAnsi();
	#pragma endregion
	
	testsPourCouvertureLectureBinaire();
	
	static const string separateurSections = "\033[95m" + trait + "\033[0m\n";

	//{ Solutionnaire du TD4:
	vector<Heros> heros = lireVectorDuFichier<Heros>("heros.bin");
	vector<Vilain> vilains = lireVectorDuFichier<Vilain>("vilains.bin");
	vector<unique_ptr<Personnage>> peronnages;  // Doit être des pointeurs pour le polymorphisme, l'énoncé ne force pas les unique_ptr.

	//TODO: Transférez les héros du vecteur heros dans une ListeLiee.
	ListeLiee<Heros> listeHeros;
	for (auto& h : heros) {
		listeHeros.push_back(h);
	}

	//TODO: Créez un itérateur sur la liste liée à la position du héros Alucard.  
	// Servez-vous de la fonction trouverParNom définie plus haut.
	separerSection("Chercher et afficher le héros Alucard.");
	Iterateur<Heros> it = trouverParNom(listeHeros, "Alucard");
	std::cout << std::endl;
	(*it).afficher(std::cout);

	//TODO: Servez-vous de l'itérateur créé précédemment pour trouver l'héroine Aya Brea, 
	// en sachant qu'elle se trouve plus loin dans la liste, en itérant sur les éléments.
	separerSection("Chercher et afficher le héroine Aya Brea.");
	while (it != listeHeros.end()) {
		if ((*it).getNom() == "Aya Brea") {
			(*it).afficher(std::cout);
			break;
		}
		it.avancer();
	}

	//TODO: Ajouter un hero bidon à la liste avant Aya Brea en vous servant de l'itérateur.
	//TODO: Assurez-vous que la taille de la liste est correcte après l'ajout.
	separerSection("Ajouter un héros bidon à la liste et vérifier la \n"
		"taille de la liste (augmentation du nombre de héros) après l'ajout.");
	std::cout << "Taille de la liste avant insertion : "
		<< listeHeros.size() << std::endl;

	std::string nomBidon = "Nom Bidon";
	std::string jeuBidon = "Jeu Bidon";
	std::string ennemiBidon = "Ennemi Bidon";
	// Note : L'implémentation proposée ne permet pas d'ajouter 
	// des alliés en dehors du ficher.
	// std::vector<std::string> alliesBidon = { "Allie Bidon1", "Allie Bidon2" };
	Heros herosBidon = Heros(nomBidon, jeuBidon, ennemiBidon);
	Iterateur<Heros> itBidon = listeHeros.insert(it, herosBidon);
	std::cout << "Taille de la liste après insertion : "
		<< listeHeros.size() << std::endl;
	// Afficher le nouvel heros ajouté :
	(*itBidon).afficher(std::cout);

	//TODO: Reculez votre itérateur jusqu'au héros Mario et effacez-le en utilisant 
	// l'itérateur, puis affichez le héros suivant dans la liste 
	// (devrait êter "Naked Snake/John").
	separerSection("Réculer l'itérateur jusqu'à Mario et effacer le. \n"
	"Ensuite, afficher le héros suivant de la liste.");
	while (it != listeHeros.begin()) {
		if ((*it).getNom() == "Mario") {
			(*it).afficher(std::cout);
			Iterateur<Heros> nextIt = it;
			++nextIt;
			std::cout << "\n\nLe héros après Mario (avant la suppression du "
				"héros Mario) est : \n" << std::endl;
			(*nextIt).afficher(std::cout);
			break;
		}
		it.reculer();
	}
	std::cout << "Taille de la liste avant le retrait du héros Mario : "
		<< listeHeros.size() << std::endl;
	listeHeros.erase(it);
	
	//TODO: Assurez-vous que la taille de la liste est correcte après le retrait.
	std::cout << "Taille de la liste après le retrait du héros Mario : "
		<< listeHeros.size() << std::endl;

	//TODO: Effacez le premier élément de la liste.
	separerSection("Enlever le premier héros de la liste et afficher la taille de la liste.");
	std::cout << "Taille de la liste avant le retrait du premier héros de la liste : "
		<< listeHeros.size() << std::endl;
	listeHeros.erase(listeHeros.begin());
	std::cout << "Taille de la liste après le retrait du premier héros de la liste : "
		<< listeHeros.size() << std::endl;

	//TODO: Affichez votre liste de héros en utilisant un itérateur. 
	// La liste débute avec le héros Randi, n'a pas Mario, et le précédent 
	// de "Aya Brea" est ce que vous avez inséré. Servez-vous des methodes 
	// begin et end de la liste...
	separerSection("Afficher l'ensemble des héros de la liste en utilisant "
		"un itrérateur.");
	for (Iterateur<Heros> listeIt = listeHeros.begin(); listeIt != listeHeros.end(); listeIt.avancer()) {
		(*listeIt).afficher(std::cout);
		std::cout << std::endl;
	}

	//TODO: Refaite le même affichage mais en utilisant une simple boucle "for" sur intervalle.
	separerSection("Afficher l'ensemble des héros de la liste en utilisant "
		"une boucle for sur intervalle.");
	for (const Heros& heros : listeHeros) {
		heros.afficher(std::cout);
		std::cout << std::endl;
	}

	//TODO: 2.1 - Utilisez un conteneur pour avoir les héros en ordre 
	// alphabétique (voir point 2 de l'énoncé).
	separerSection("Utiliser un conteneur pour placer les héros en ordre alphabétique. \n"
		"Afficher les héros en ordre alphabétique.");
	std::map<std::string, Heros> mapHeros;
	
	for (const auto& h : heros) {
		mapHeros[h.getNom()] = h;
	}
	
	for (const auto& h : mapHeros) {
		h.second.afficher(std::cout);
		std::cout << std::endl;
	}

	// TODO: 2.2 Affichez un des héros en le trouvant par son nom dans le conteneur en 2.1. 
	// Donnez en commentaire la complexité en moyenne de cette recherche(pas de y												
	// l’affichage une fois trouvé).Expliquez pourquoi en commentaire.
	separerSection("Trouver un héros par son nom dans le conteneur en <2.1> et affichez-le.");
	auto itRockman = mapHeros.find("Rockman/Mega Man");
	if (itRockman != mapHeros.end()) {
		itRockman->second.afficher(std::cout);
	}
	// La complexité (en moyenne) de la recherche d'un héros par son nom dans un "map" 
	// (ordered) est O(logn), car les éléments à rechercher sont rangés dans un arbre.

	// 2.3 Selon vous, lors d’une recherche d’un héros par le nom, quel conteneur 
	// entre la liste liée en 1. et celui utilisé en 2.1 permet la recherche 
	// la plus rapide.Expliquez pourquoi en commentaire.
	
	// Liste liée : recherche en O(n), car il faut parcourir l'ensemble de la liste 
	// (au pire cas) afin de déterminer où est situé l'élément recherché.

	// Avec un "map" (ordred), qui est un conteneur qui implémente la recherche en 
	// utilisant un arbre, la recherche d'un élément, au pire cas est en O(logn).

	// La rechreche qui utilise le conteneur "map" est donc plus rapide que la recherche
	// qui utilise la liste liée.

	//TODO: Assurez-vous de n'avoir aucune ligne non couverte dans les classes pour la liste liée.  
	// Il peut y avoir des lignes non couvertes dans les personnages...
	separerSection("Fin du TP5.");
}
