﻿// Seulement pour Windows pas sous Cygwin.
#if defined(_WIN32) && !defined(__CYGWIN__)
#define NOMINMAX 1
#define WIN32_LEAN_AND_MEAN 1
#include <windows.h>

#include <streambuf>
#include <cstdio>

namespace bibliotheque_cours {

// Les fonctions utilisées pour accéder à cin, mises dans une classe pour permettre de faire des mocks de ces fonctions.
class ConsoleReadFunctions {
public:
	// Définitions de consoleapi.h (avec type WCHAR* au lieu LPVOID pour le buffer) :
	virtual BOOL ReadConsoleW(
		_In_ HANDLE hConsoleInput,
		_Out_writes_to_(nNumberOfCharsToRead, *lpNumberOfCharsRead) WCHAR* lpBuffer,
		_In_ DWORD nNumberOfCharsToRead,
		_Out_ _Deref_out_range_(<= , nNumberOfCharsToRead) LPDWORD lpNumberOfCharsRead,
		_In_opt_ PCONSOLE_READCONSOLE_CONTROL pInputControl
	) const;

	virtual BOOL GetConsoleMode(
		_In_ HANDLE hConsoleHandle,
		_Out_ LPDWORD lpMode
	) const;

	// Définitions de stdio.h :
	virtual int fgetc(_Inout_ FILE* _Stream) const;
};

class ifilebuf_console_utf8;

class ifilebuf_console_utf8_instance {
public:
	static std::streambuf* get();
	static void setmock(ConsoleReadFunctions* consoleReadFunctions);

	static ifilebuf_console_utf8* get_derived();
};

}
#endif
