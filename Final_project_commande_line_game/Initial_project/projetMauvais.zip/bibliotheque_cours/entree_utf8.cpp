﻿// Streambuf pour que ce soit possible de lire correctement de la console quand elle est en mode UTF-8 sous Windows.
// Dans la bibliothèque actuelle de MSVC: cin utilise un filebuf qui, dans sa méthode virtuelle uflow() utilise fgetc pour lire le prochain caractère, mais fgetc retourne actuellement 0 pour un caractère non ASCII quand la console est est UTF-8. Actuellement, il semble que la manière de lire correctement la console est d'utiliser ReadConsoleW ( https://social.msdn.microsoft.com/Forums/vstudio/en-US/6db367e1-6b39-4c91-bd08-e3779ae5fc23/problems-with-readingwriting-utf8-characters-to-console?forum=vcgeneral ).
// Par Francois-R.Boyer@PolyMtl.ca

// Seulement pour Windows pas sous Cygwin.
#if defined(_WIN32) && !defined(__CYGWIN__)
#include "entree_utf8.hpp"

#include <streambuf>
#include <array>
#include <gsl/gsl_assert>
#include <cstdio>
#include <io.h>  // _get_osfhandle

namespace bibliotheque_cours {

// Définitions venant normalement de <unistd.h> dans les systèmes POSIX, mais en majuscules car ce sont des #define; Windows utilise les même numéros de fichiers mais MSVC n'a pas unistd.h.
[[maybe_unused]] static constexpr int stdin_fileno = 0, stdout_fileno = 1, stderr_fileno = 2;


// Spécialisation simple d'un streambuf d'entrée.  On supporte tout de même les reopen de stdin.  N'a pas d'optimisation pour lire beaucoup de caractères d'un coup, mais ce n'est pas requis pour l'entrée de la console; si le programme est fait pour recevoir des gros fichiers par cin, ça pourrait l'être.
class ifilebuf_console_utf8 : public std::streambuf {
	static const int max_utf8_code_length = 4;
	static const int unget_space = 2*max_utf8_code_length;
	static const int buffer_size = unget_space + 4*max_utf8_code_length;

	static constexpr int input_fileno = stdin_fileno;
	inline static const FILE* input_file = stdin;

	// streambuf utilise le "Non-Virtual Interface idiom", comme la majorité des classes avec méthodes virtuelles dans la bibliothèque standard C++ (voir l'article de Herb Sutter http://www.gotw.ca/publications/mill18.htm).  Il n'y a donc pas de méthode virtuelle publique.

protected:
	// Constructeur protégé pour "singleton".
	ifilebuf_console_utf8() {
		setg(buffer_begin_after_unget_space, buffer_begin_after_unget_space, buffer_begin_after_unget_space);
	}
	friend class ifilebuf_console_utf8_instance;

	// sungetc ou sputbackc de la classe de base réussissent directement lorsque eback < gptr et que le caractère à remettre est celui qui était déjà le précédent caractère.  Sinon, pbackfail est appélé sans argument (sungetc) ou avec le nouveau caractère à mettre (sputbackc).
	int_type pbackfail(int_type c = traits_type::eof()) override {
		if (eback() >= gptr() && !rewindUnget(c != traits_type::eof()))
			return traits_type::eof();
		Expects(eback() < gptr());
		gbump(-1);
		if (c == traits_type::eof())
			return traits_type::to_int_type(*gptr());
		*gptr() = traits_type::to_char_type(c);
		return c;
	}


	// uflow de la classe de base fait appel à underflow pour aller chercher un/des caractères et les placer dans le tampon d'entrée.  Les méthodes publiques de streambuf appellent uflow seulement si gptr() == nullptr ou gptr() >= egptr()  (https://en.cppreference.com/w/cpp/io/basic_streambuf/uflow).  gptr() étant la tête de lecture et egptr() étant le suivant de la dernière position (donc, quand gptr() == egptr() le tampon est vide).
	int_type underflow() override {
		Expects(gptr() == nullptr || gptr() >= egptr());
		HANDLE h = getHandle();
		bool success = isConsole(h) ? readFromConsole(h) : readFromStdin();
		if (!success)
			return traits_type::eof();
		Ensures(gptr() != nullptr && gptr() < egptr());
		return traits_type::to_int_type(*gptr());
	}

private:
	// Le handle peut changer lors d'un reopen, donc on va le chercher à chaque fois.
	static HANDLE getHandle() { return reinterpret_cast<HANDLE>( _get_osfhandle(stdin_fileno) ); }
	bool isConsole(HANDLE fileHandle) {
		DWORD mode; return console->GetConsoleMode(fileHandle, &mode) == TRUE;
	}

	bool readFromConsole(HANDLE h) {
		Expects(isConsole(h));
		wchar_t buf[2] = {};
		DWORD nCodesRead = 0;
		do {
			console->ReadConsoleW(h, &buf[0], 1, &nCodesRead, nullptr);
			if (nCodesRead == 0)
				return false;
		} while (buf[0] == '\r');  // Saute les '\r' des fins de lignes "\r\n" sous Windows.
		// Si on a la première moitié d'une paire de codets d'indirection (surrogate), on doit lire la deuxième moitié pour former le point de code complet.
		if (isHighSurrogate(buf[0])) {
			console->ReadConsoleW(h, &buf[1], 1, &nCodesRead, nullptr);
			++nCodesRead;
		}

		int codeLength = WideCharToMultiByte(CP_UTF8, 0, buf, nCodesRead, ensureSpaceLeft(max_utf8_code_length), max_utf8_code_length, nullptr, nullptr);
		advanceEgptr(codeLength);
		return true;
	}

	bool readFromStdin() {
		int ch = console->fgetc(stdin);
		if (ch == EOF)
			return false;

		ensureSpaceLeft(1)[0] = traits_type::to_char_type(ch);
		advanceEgptr(1);
		return true;
	}

	// Tente de reculer d'un caractère avant eback, retourne faux si échec.
	// Le paramètre vrai indique que la donnée sera remplacée donc n'a pas à être initialisée.
	bool rewindUnget(bool isForReplace) {
		if (eback() > buffer_.data() && (isForReplace || buffer_circular_end > egptr())) {
			setg( eback()-1, gptr(), egptr() );  --buffer_circular_end;
			if (!isForReplace)
				*eback() = *buffer_circular_end;
			return true;
		}
		return false;
	}

	char* ensureSpaceLeft(int neededSpace) {
		if (spaceLeft() < neededSpace) {
			buffer_circular_end = egptr();
			setg(buffer_begin_after_unget_space, buffer_begin_after_unget_space, buffer_begin_after_unget_space);
		}
		Ensures(spaceLeft() >= neededSpace);
		return egptr();
	}

	void advanceEgptr(int n) {
		setg(eback(), gptr(), egptr() + n);
	}

	ptrdiff_t spaceLeft() {
		return buffer_end - egptr();
	}

	static bool isHighSurrogate(wchar_t c) { return (char16_t(c) & 0xFC00) == 0xD800; }

	// On utilise un 4e pointeur en plus des 3 standard d'un streambuf.  Ce qu'il y a entre le egptr (pointeur de fin des données placées dans le tampon) et le buffer_circular_end sont des données qui viennent de lectures avant le eback; on peut reculer avant le eback en prenant les données avant le buffer_circular_end (mais pas avant le egptr), s'il y en a.
	std::array<char, buffer_size> buffer_{};
	char* buffer_circular_end = buffer_.data();
	char* const buffer_begin_after_unget_space = buffer_.data() + unget_space;
	char* const buffer_end = &buffer_.back() + 1;

	// Pour l'injection de dépendances.
	inline static ConsoleReadFunctions consoleReadFunctions;
	ConsoleReadFunctions* console = &consoleReadFunctions;
};

// Permet d'obtenir l'instance comme un std::streambuf*, la classe ifilebuf_console_utf8 n'a dont pas besoin d'être connue de l'extérieur (c'est aussi la raison pour laquelle cette fonction n'est pas membre de la classe).
// Suit un patron style "singleton"; un process Windows ne peut avoir qu'une console, s'il y avait deux instances elles liraient en fait de la même source et auraient chacune seulement une partie de ce qui est entré.
std::streambuf* ifilebuf_console_utf8_instance::get() {
	return get_derived();
}
ifilebuf_console_utf8* ifilebuf_console_utf8_instance::get_derived() {
	static ifilebuf_console_utf8 instance;
	return &instance;
}

void ifilebuf_console_utf8_instance::setmock(ConsoleReadFunctions* consoleReadFunctions) {
	get_derived()->console = consoleReadFunctions != nullptr ? consoleReadFunctions : &ifilebuf_console_utf8::consoleReadFunctions;
}


BOOL ConsoleReadFunctions::ReadConsoleW(
	_In_ HANDLE hConsoleInput,
	_Out_writes_to_(nNumberOfCharsToRead, *lpNumberOfCharsRead) WCHAR* lpBuffer,
	_In_ DWORD nNumberOfCharsToRead,
	_Out_ _Deref_out_range_(<= , nNumberOfCharsToRead) LPDWORD lpNumberOfCharsRead,
	_In_opt_ PCONSOLE_READCONSOLE_CONTROL pInputControl
) const {
	return ::ReadConsoleW(hConsoleInput, lpBuffer, nNumberOfCharsToRead, lpNumberOfCharsRead, pInputControl);
}

BOOL ConsoleReadFunctions::GetConsoleMode(
	_In_ HANDLE hConsoleHandle,
	_Out_ LPDWORD lpMode
) const {
	return ::GetConsoleMode(hConsoleHandle, lpMode);
}

int ConsoleReadFunctions::fgetc(_Inout_ FILE* _Stream) const {
	return ::fgetc(_Stream);
}


}
#endif
