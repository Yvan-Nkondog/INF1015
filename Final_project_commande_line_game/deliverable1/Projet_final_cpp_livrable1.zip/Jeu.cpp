#include <cctype>
#include <string>
#include "Jeu.hpp"
#include "Case.hpp"
#include "Carte.hpp"
#include "Commande.hpp"
#include <iostream>
#include "DonneesMonde.hpp"

void Jeu::executer()
{
	std::cout << GAME_TITLE << '\n' << std::endl;

	std::cout << GAME_DESCRIPTION << '\n' << std::endl;

	carte_.creerMonde();
	positionCourante_ = carte_.obtenirCaseDepart();
	afficherSalle();

	std::string commande;

	while (true) {
		std::cout << "\n> ";

		std::getline(std::cin, commande);

		if (commande == "quitter") {
			break;
		}
		traiterCommande(commande);
	}
	std::cout << "Vous avez mis un terme a la partie." << std::endl;
}

void Jeu::afficherSalle() const
{
	positionCourante_->afficherDescriptionCompleteCase();
}

void Jeu::traiterCommande(const std::string& commande)
{
	switch (convertirCommande(commande)) {
		case TypeCommande::Look:
		{
			afficherSalle();
			break;
		}
			
		case TypeCommande::Aller:
		{
			char direction = static_cast<char>(std::toupper(commande[0]));
			Case* destination = positionCourante_->obtenirDestination(direction);

			if (destination != nullptr) {
				positionCourante_ = destination;
				afficherSalle();
			}
			else {
				std::cout << DIRECTION_INACCESSIBLE << std::endl;
			}
			break;
		}
		case TypeCommande::Utiliser:
		{
			std::string quoi;
			std::cout << "Quel objet souhaitez-vous utiliser ?" << std::endl;
			std::getline(std::cin, quoi);
			if (quoi == "echelle") {
				if (positionCourante_->obtenirNom() == "Petite chambre") {
					positionCourante_ = carte_.obtenirCaseAPartirDeNom("Grenier");
					afficherSalle();
				}
				else if (positionCourante_->obtenirNom() == "Grenier") {
					positionCourante_ = carte_.obtenirCaseAPartirDeNom("Petite chambre");
					afficherSalle();
				}
				else {
					std::cout << OBJET_INCONNU << std::endl;
				}
			}
			else {
				std::cout << OBJET_INCONNU << std::endl;
			}
			break;
		}

		default:
			std::cout << COMMANDE_INCONNUE << std::endl;
			break;
	}
}
