#pragma once
#include "Carte.hpp"
#include "Case.hpp"


class Jeu
{
public:
	void executer();

private:
	Carte carte_;
	Case* positionCourante_ = nullptr;
	void afficherSalle() const;
	void traiterCommande(const std::string& commande);
};
