#include <string>
#include <vector>
#include <iostream>
#include "Case.hpp"


Case::Case(const std::string& nom, const std::string& description, 
	std::vector<std::string> destinations) :
	nom_(nom),
	description_(description)
{
	for (const auto& destination : destinations) {
		destinationsPossibles_.push_back(destination);
	}
}

void Case::ajouterSortie(char direction, Case* destination)
{
	sorties_[direction] = destination;
}

const std::string& Case::obtenirNom() const
{
	return nom_;
}

const std::string& Case::obtenirDescription() const
{
	return description_;
}

void Case::afficherDescriptionCompleteCase() const {
	std::cout << description_ << std::endl;
	for (std::size_t i = 0; i < destinationsPossibles_.size(); i++) {
		std::cout << destinationsPossibles_[i] << std::endl;
	}
}

Case* Case::obtenirDestination(char direction) const {
	auto it = sorties_.find(direction);

	if (it != sorties_.end()) {
		return it->second;
	}
	return nullptr;
}
