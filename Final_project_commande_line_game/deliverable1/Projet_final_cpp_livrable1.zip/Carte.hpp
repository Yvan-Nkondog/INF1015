#pragma once
#include <vector>
#include <memory>
#include "Case.hpp"

class Carte {
public:
	void creerMonde();
	Case* obtenirCaseDepart() const;
	Case* obtenirCaseAPartirDeNom(const std::string& nom) const;

private:
	std::vector<std::unique_ptr<Case>> cases_;
	Case* caseDepart_ = nullptr;
};
