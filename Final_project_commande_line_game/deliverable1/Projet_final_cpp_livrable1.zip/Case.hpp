#pragma once
#include <string>
#include <unordered_map>
#include <vector>


class Case {
public:
	Case(const std::string& nom, const std::string& description, std::vector<std::string> destinations);

	void ajouterSortie(char direction, Case* destination);
	const std::string& obtenirNom() const;
	const std::string& obtenirDescription() const;
	void afficherDescriptionCompleteCase() const;
	Case* obtenirDestination(char direction) const;

private:
	std::string nom_;
	std::string description_;
	std::vector<std::string> destinationsPossibles_;
	// Added to establish connections.
	std::unordered_map<char, Case*> sorties_;
};
