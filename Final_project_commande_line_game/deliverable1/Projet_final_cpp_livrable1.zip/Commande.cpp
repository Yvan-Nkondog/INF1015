#include <unordered_map>
#include <string>
#include "Commande.hpp"


TypeCommande convertirCommande(const std::string& commande)
{
	static const std::unordered_map<std::string, TypeCommande> commandes =
	{
		{"look", TypeCommande::Look},
		{"utiliser", TypeCommande::Utiliser}
	};

	auto it = commandes.find(commande);
	if (it != commandes.end()) {
		return it->second;
	}

	if (commande.size() == 1) {
		return TypeCommande::Aller;
	}

	return TypeCommande::Inconnue;
}


