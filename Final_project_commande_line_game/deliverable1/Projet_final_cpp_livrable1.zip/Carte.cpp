#include <vector>
#include <memory>
#include <unordered_map>
#include "Case.hpp"
#include "Carte.hpp"
#include "DonneesMonde.hpp"

void Carte::creerMonde()
{
	std::unordered_map<std::string, Case*> connexionCases;

	for (const auto& donneesCase : monde) {
		auto nouvelleCase = std::make_unique<Case>(
			donneesCase.nom,
			donneesCase.description,
			donneesCase.destinationsPossibles
		);

		if (donneesCase.nom == CASE_DEPART) {
			caseDepart_ = nouvelleCase.get();
		}

		connexionCases[donneesCase.nom] = nouvelleCase.get();

		cases_.push_back(std::move(nouvelleCase));
	}

	connexionCases["Entree"]->ajouterSortie('N', connexionCases["Couloir"]);
	connexionCases["Entree"]->ajouterSortie('E', connexionCases["Salon"]);

	connexionCases["Salon"]->ajouterSortie('W', connexionCases["Entree"]);

	connexionCases["Couloir"]->ajouterSortie('S', connexionCases["Entree"]);
	connexionCases["Couloir"]->ajouterSortie('N', connexionCases["Cuisine"]);
	connexionCases["Couloir"]->ajouterSortie('W', connexionCases["Petite chambre"]);

	connexionCases["Petite chambre"]->ajouterSortie('E', connexionCases["Couloir"]);

	connexionCases["Cuisine"]->ajouterSortie('S', connexionCases["Couloir"]);
}

Case* Carte::obtenirCaseDepart() const 
{
	return caseDepart_;
}

Case* Carte::obtenirCaseAPartirDeNom(const std::string& nom) const
{
	for (const auto& cellule : cases_) {
		if (cellule->obtenirNom() == nom) {
			return cellule.get();
		}
	}
	return nullptr;
}
