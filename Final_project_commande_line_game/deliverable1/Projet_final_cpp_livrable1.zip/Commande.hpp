#pragma once
#include <unordered_map>

enum class TypeCommande
{
	Aller,
	Look,
	Utiliser,
	Inconnue
};

TypeCommande convertirCommande(const std::string& commande);
