#pragma once
#include <string>
#include <vector>


constexpr auto GAME_TITLE = ">>>>> INF1015 - PROJET FINAL (JEU) <<<<<";
constexpr auto GAME_DESCRIPTION = "Ce jeu permet a un utilisateur de se deplacer entre "
								  "les cases d'un monde, en entrant des commandes (texte) "
								  "dans la ligne de commande. Les caracteres (commandes) "
								  "N, S, E, et W, (ou n, s, e, et w) permettent de se "
								  "deplacer entre les cases du monde. "
								  "La commande <utiliser> permet de selectionner un "
								  "objet. Dans cette version, le seul objet disponible " 
								  "est une <echelle> qui permet de passer de la "
								  "<petite chambre> au <grenier> et inversement.";
constexpr auto CASE_DEPART = "Entree";
constexpr auto DIRECTION_INACCESSIBLE = "Ne peut pas aller la.";
constexpr auto COMMANDE_INCONNUE = "Commande inconnue.";
constexpr auto OBJET_INCONNU = "Je ne sais pas ca.";

struct CaseNameDescriptionDirection
{
	std::string nom;
	std::string description;
	std::vector<std::string> destinationsPossibles;
};

inline std::vector<CaseNameDescriptionDirection> monde =
{
	{
		"Entree",
		"Vous etes dans l'entree. Il y a un tapis sur le sol.",
		{"Le couloir est au nord (N).", "Le salon est a l'est (E)."}
	},
	{
		"Salon",
		"Vous etes dans le salon.",
		{"L'entree est a l'ouest (W)."}
	},
	{
		"Couloir",
		"Vous etes dans le couloir.",
		{"La cuisine est au nord (N).", "La petite chambre est a l'ouest (W).", "L'entree est au sud (S)."}
	},
	{
		"Petite chambre",
		"Vous etes dans une petite chambre. En dehors d'etre petite, la seule autre chose qu'elle a de speciale est d'avoir une echelle dans le coin.",
		{"Le couloir est a l'est (E).", "Une echelle permet de monter au grenier."}
	},
	{
		"Cuisine",
		"Vous etes dans la cuisine. Elle est tres jaune 'beurre' comme la mode d'une certaine epoque.",
		{"Le couloir est au sud (S)."}
	},
	{
		"Grenier",
		"Vous etes dans le grenier, il est sombre.",
		{"Une echelle permet de descendre."}
	}
};
